<p>Dear {{$data['username']}},Your signup form had been approved.</p>
{{-- <p>အကြောင်းပြချက် : {{$data['cmt']}}</p> --}}