<p>Dear {{$data['username']}},Your signup form had been denied.</p>
<p>အကြောင်းပြချက် : {{$data['cmt']}}</p>
<p>Please refill the form.</p>