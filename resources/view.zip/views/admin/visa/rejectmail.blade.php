<p>Dear {{$data['username']}},Your visa application form had been rejected.</p>
<p>အကြောင်းပြချက် : {{$data['cmt']}}</p>