<p>Dear {{$data['username']}},Your Visa Application had been approved.</p>
{{-- <p>အကြောင်းပြချက် : {{$data['cmt']}}</p> --}}