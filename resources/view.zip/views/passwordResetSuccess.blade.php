@extends('layout')
@section('content')
	<hr style="opacity: 0.4">

	<h5 style="color: green;" class="text-center"></h5>

	<div class="container mb-5" style="">
		<div class="alert alert-success alert-dismissible fade show" role="alert">
		  <span><strong><span class="mm">သင်၏စကားဝှက်ကိုပြောင်းပြီးပါပြီ</span><span class="eng">Your Password has been changed.</span></strong></span>
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		    <span aria-hidden="true">&times;</span>
		  </button>
		</div>
	</div>
@endsection